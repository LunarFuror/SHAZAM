public class ShazamMain{
	
	public static void main(String[] args){
		ShazamUI ui = new ShazamUI();
	}
	
}